{application,poolboy,
             [{description,"A hunky Erlang worker pool factory"},
              {vsn,"1.5.2"},
              {applications,[kernel,stdlib]},
              {registered,[poolboy]},
              {maintainers,["Devin Torres","Andrew Thompson","Kurt Williams"]},
              {licenses,["Unlicense","Apache 2.0"]},
              {links,[{"GitHub","https://github.com/devinus/poolboy"}]},
              {modules,[poolboy,poolboy_sup,poolboy_worker]}]}.
